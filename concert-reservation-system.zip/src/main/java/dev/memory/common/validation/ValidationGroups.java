package dev.memory.common.validation;

public class ValidationGroups {
    public interface NotBlankGroup {}
    public interface SizeGroup {}
    public interface PatternGroup {}
    public interface MinMaxGroup {}
    public interface AssertTrueGroup {}
}
