package dev.memory.concert.controller;

import dev.memory.concert.dto.ConcertCreateRequest;
import dev.memory.concert.dto.ConcertResponse;
import dev.memory.concert.service.ConcertService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/api/v1/concerts")
public class ConcertRestController {

    private final ConcertService concertService;

    @PostMapping()
    public ResponseEntity<Void> createConcertByAdmin(
            @AuthenticationPrincipal User user,
            @Valid @RequestBody ConcertCreateRequest request) {

        // TODO 유효성 검증 했다는 가정하에
        Long id = Long.parseLong(user.getUsername());

        concertService.createConcertByAdmin(id, request);

        return ResponseEntity.ok().build();
    }

    @GetMapping()
    public ResponseEntity<Page<ConcertResponse>> getConcerts(
            @PageableDefault(size = 10) Pageable pageable
    ){

        Page<ConcertResponse> page = concertService.getConcerts(pageable);

        return ResponseEntity.ok().body(page);
    }
}
