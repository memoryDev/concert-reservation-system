# concert-reservation-system
동시성 제어 및 대용량 트래픽 처리를 고려한 콘서트 예매 서비스 (Spring Boot, Redis, Docker)
